Hướng dẫn all in one chặn thu hồi, OTA, ads(domain quảng cáo tự động từ bigdragon hostvn) 

Các bạn vào github bên dứoi lấy video hướng dẫn (video hướng dẫn by Lãng Khách và Trần Hoàng Long)

Bước 1. Đưa máy về chế độ giám sát.(Xem video). Xong bước 1 nhớ khởi động lại máy

https://youtu.be/cu0n0lT9C-A

https://youtu.be/eNxZQqvD4DI

Bước 2. Cài đặt config: Có 2 lựa chọn. 
Mở link trong github click raw. Alow. Sau đó cài đặt profile

Done. Chúc mừng  bạn không lo bị thu hồi chứng chỉ nữa. Và bạn có thể sideload ipa ki giói hạn. Có thể tham khảo appcake để cài ipa

Link github:
https://github.com/langkhach270389/Antirevoke-OTABlocked-Adsblock?files=1